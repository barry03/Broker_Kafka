import tweepy
from tweepy import OAuthHandler
from tweepy import Stream
from kafka import KafkaProducer
import json
from pymongo import MongoClient
import time
access_key = '1471777355517632512-ChMGZtgAClUq5OINIWUEkHqAnmaKzm'
access_secret = 'w1UWAG67XkLV8QV2z5D1uWSMXcaciuEEWMzM9hHaF7SnI'
consumer_key = 'bgExj0FscePSCpogsaae4Bd7X'
consumer_secret = 'wJPrSEfTZagI85jww9sGA17JHMWHDypBKPfy3tgmIgCHR6PBso'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_key, access_secret)
 
api = tweepy.API(auth, wait_on_rate_limit=True)

topic_name = "Twitter_Barry"
search_words = ['#WorldCup']

producer = KafkaProducer(bootstrap_servers='localhost:9092',
                                 value_serializer=lambda v: json.dumps(v).encode('utf-8'))

for tweet in tweepy.Cursor(api.search_tweets,q=search_words,include_entities=True,
                           lang="en",
                           since_id=0).items():
    print({"date":tweet.created_at,"text":tweet.text.encode('utf-8')})
    producer.send(topic_name,value={"date":str(tweet.created_at),"text":str(tweet.text.encode('utf-8'))})
    time.sleep(10)