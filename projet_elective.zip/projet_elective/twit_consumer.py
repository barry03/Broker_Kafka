from kafka import KafkaConsumer
from pymongo import MongoClient
import json

# Connect to MongoDB and pizza_data database
try:
   client = MongoClient('localhost',27017)
   db = client.Twitter_db
   print("Connected successfully!")
except:  
   print("Could not connect to MongoDB")
    
# connect kafka consumer to desired kafka topic	
topic_name = "Twitter_Barry"
consumer = KafkaConsumer(topic_name,bootstrap_servers=['localhost:9092'],value_deserializer=lambda x: json.loads(x.decode('utf-8')))

for msg in consumer:
    tweets = json.loads(json.dumps(msg.value))
    date = tweets['date']
    text = tweets['text']
    
    
    try:
        tweets_cup = {'date':date,'text':text}
        res = db.tweets.insert_one(tweets_cup)
        ("Insert good")
    except:
        print("Could not insert into MongoDB")